class box:
    def __init__(self):
        '''
        If you can't get the flag, go to sleep Zzz
        '''
        self.secret = "YSAqIC0zMiArIGIgKiA5MCArIGMgKiA5OCArIGQgKiAyMyArIGUgKiA1NSA9PSAzMzMzMjIKYSAqIC0zMjIgKyBiICogMzIgKyBjICogNjggKyBkICogMTIzICsgZSAqIDY3ID09IDcwNzcyNAphICogLTM0ICsgYiAqIDMyICsgYyAqIDQzICsgZCAqIDI2NiArIGUgKiA4ID09IDEyNzI1MjkKYSAqIC0zNTIgKyBiICogNSArIGMgKiA1OCArIGQgKiAzNDMgKyBlICogNjUgPT0gMTY3MjQ1NwphICogLTMyMSArIGIgKiA5NzAgKyBjICogOTM4ICsgZCAqIDIzMSArIGUgKiA1NTUgPT0gMzM3MjM2Nw=="
        print("This box contains the flag. r00t2024{a_b_c_d_e}")

class eavesdropping_device:
    def __init__(self):
        print("This is a eavesdropping device that might help you.")
    
    def eavesdrop(self,box,t):
        '''
        Try to enter the time to eavesdrop on the secrets in the box
        '''
        if(t<len(box.secret)):
            print(box.secret[t],end="")
        else:
            exit()
        
